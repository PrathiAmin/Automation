package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LandingPage {
	public WebDriver driver;
	//By signin = By.id("dropdownCurrency");
	
	public LandingPage(WebDriver driver){
		this.driver = driver;
	}
	
	By myAccount = By.xpath("(//*[@id='dropdownCurrency'])[2]");
	
	 public WebElement getMyAccount(){
		 return  driver.findElement(myAccount);
		
	   }
	 
   By login = By.cssSelector("a[href*='login']");
  
   public WebElement getLogin(){
	   return driver.findElement(login);
	    
   }
   
   //By logo = By.xpath("//a/img[@src='https://www.phptravels.net/uploads/global/logo.png']");
   
   By logo = By.cssSelector("img[src='https://www.phptravels.net/uploads/global/logo.png']");
   public WebElement getLogo(){
	   return driver.findElement(logo);
   }
   
  // By navbar = By.xpath("//div[@class='navbar navbar-expand-lg']");
   By navbar = By.cssSelector("div[class='navbar navbar-expand-lg']");
   public WebElement getNavBar(){
	   return driver.findElement(navbar);
   }
		   
}
