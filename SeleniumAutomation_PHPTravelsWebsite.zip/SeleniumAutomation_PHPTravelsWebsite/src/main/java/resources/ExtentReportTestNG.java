package resources;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ExtentReportTestNG {
	static ExtentReports extent;

	public static ExtentReports getReportObject() {

		String path = System.getProperty("user.dir") + "\\reports\\index.html";
		ExtentHtmlReporter reporter = new ExtentHtmlReporter(path);
		reporter.config().setDocumentTitle("Test Automation Results");
		reporter.config().setReportName("Web Automation Results");

		extent = new ExtentReports();
		extent.attachReporter(reporter); // need to pass the object of the
											
		extent.setSystemInfo("tester", "Prathibha");
		return extent;

	}

}
