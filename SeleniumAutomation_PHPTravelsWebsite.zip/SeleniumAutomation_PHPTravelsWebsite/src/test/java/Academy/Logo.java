package Academy;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObjects.LandingPage;
import resources.Base;

public class Logo extends Base {
	public WebDriver driver;
	
	public static Logger log = LogManager.getLogger(Logo.class.getName());
	
	@BeforeTest
	public void initialize() throws IOException{
		driver = initializeDriver();
		//driver.get("");
		driver.get(prop.getProperty("url"));
		
	}
   
	@Test
   public  void logoImageValidation() throws IOException{
		
		
	LandingPage lp = new LandingPage(driver);
	WebElement logo = lp.getLogo();
	Boolean ImagePresent = 
			(Boolean)((JavascriptExecutor)driver).executeScript("return arguments[0].complete && typeof arguments[0].naturalWidth != \"undefined\" && arguments[0].naturalWidth > 0", logo);
	if (!ImagePresent) {
		System.out.println("Image not displayed.");
		log.info("Image not displayed.");
	  } else {
		  System.out.println("Image displayed.");
		  log.info("Image  displayed.");
	}	
	
	 
   }

	 @AfterTest
	   public void tearDown(){
		   driver.close();
	   }

}

