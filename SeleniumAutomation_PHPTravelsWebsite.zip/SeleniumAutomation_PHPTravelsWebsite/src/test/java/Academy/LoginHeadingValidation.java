package Academy;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageObjects.LandingPage;
import pageObjects.LoginPage;
import resources.Base;

//Adding Logs - Log 4j
//Generating html reports
//Screenshots on failure
//Jenkins Integration
public class LoginHeadingValidation extends Base {
	public WebDriver driver;

	public static Logger log = LogManager.getLogger(LoginHeadingValidation.class.getName());

	@BeforeMethod
	public void initialize() throws IOException {

		driver = initializeDriver();
		log.info("Driver is initialized");

		driver.get(prop.getProperty("url"));
		log.info("Navigated to the home page");
	}
	@Test()
	public void loginHeadingValidation() throws IOException {
		LandingPage lp = new LandingPage(driver);
		lp.getMyAccount().click();
		lp.getLogin().click();
		LoginPage loginPage = new LoginPage(driver);
		log.info("Verifying the login page heading name");
	//	assert.assertEquals("", "Login");
		//String loginHeader= loginPage.getLoginPageHeader().getText();
		Assert.assertEquals(loginPage.getLoginPageHeader().getText(), "LoginPage"); //failing this test intentionally to get error screenshot
		log.info(" Login page heading is validated");
	}

	

	@AfterMethod
	public void tearDown() {
		driver.close();
	}
}
