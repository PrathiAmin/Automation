package Academy;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageObjects.LandingPage;
import pageObjects.LoginPage;
import resources.Base;


//Adding Logs - Log 4j
//Generating html reports
//Screenshots on failure
//Jenkins Integration
public class HomePage extends Base {
	public WebDriver driver;
	
	public static Logger log = LogManager.getLogger(HomePage.class.getName());
	@BeforeMethod
	public void initialize() throws IOException{
		
		driver = initializeDriver();
		log.info("Driver is initialized");
		//driver.get("");
		driver.get(prop.getProperty("url"));
		log.info("Navigated to the home page");
	}
    @Test(dataProvider="getData")
 public void homepageNavigation(String username, String password, String text) throws IOException{
	
	LandingPage lp = new LandingPage(driver);
	lp.getMyAccount().click();
	lp.getLogin().click();
	
	LoginPage loginPage = new LoginPage(driver);
	loginPage.getEmail().sendKeys(username);
	loginPage.getPassword().sendKeys(password);
	loginPage.clickLogin().click();
	log.info("Successfully validated login for: " +text);
 }
   @DataProvider //parameterization and data driving
	public Object[][] getData(){
	// Row stands for how many different data types test should run
	   //Column stands for how many values per each test
	   
	Object[][] data = new Object[2][3];
	//0th row:
	data[0][0] = "user@phptravels.com";
	data[0][1]="demouser";
	data[0][2] = "valid user with valid password";
	
	//1st row
	data[1][0] = "user@phptravels.com";
	data[1][1] = "demo123";
	data[1][2] = "valid username and invalid password";
	
	return data;
	} 	
   @AfterMethod
   public void tearDown(){
	   driver.close();
   }
}
